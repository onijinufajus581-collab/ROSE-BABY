package com.rose.ai

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.*
import kotlinx.coroutines.launch

@Composable
fun ApiSettingsScreen(onBack:()->Unit,onSelected:(String,String,String,String)->Unit) {
    val context= LocalContext.current
    val saved=remember { KeyStore.selection(context) }
    var selected by remember { mutableStateOf(AIManager.providers.first{it.name==saved.first}) }
    var model by remember { mutableStateOf(saved.second) }
    var key by remember { mutableStateOf(KeyStore.read(context,selected.name)) }
    var show by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope= rememberCoroutineScope()
    Column(Modifier.fillMaxSize().background(Deep).statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(18.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically) {
            IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null,tint=Cyan)}
            Text("AI API MANAGER",fontSize=20.sp,color=Color.White)
        }
        Spacer(Modifier.height(16.dp))
        Text("Choose AI Provider",fontSize=18.sp,color=Color.White)
        AIManager.providers.forEach { p ->
            Card(Modifier.fillMaxWidth().padding(vertical=5.dp).clickable { selected=p; model=p.defaultModel; key=KeyStore.read(context,p.name); status="" },colors=CardDefaults.cardColors(containerColor=Panel),border=if(selected.name==p.name) BorderStroke(1.dp,Cyan) else null) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) { RadioButton(selected.name==p.name,{selected=p;model=p.defaultModel;key=KeyStore.read(context,p.name)},colors=RadioButtonDefaults.colors(selectedColor=Cyan)); Text(p.name,color=Color.White,fontSize=16.sp) }
                    Text(p.base,color=Cyan,fontSize=10.sp)
                }
            }
        }
        Spacer(Modifier.height(15.dp))
        Text("API KEY",color=Cyan)
        OutlinedTextField(value=key,onValueChange={key=it},modifier=Modifier.fillMaxWidth(),placeholder={Text("Paste your API Key")},singleLine=true,visualTransformation=if(show) VisualTransformation.None else PasswordVisualTransformation(),trailingIcon={TextButton(onClick={show=!show}){Icon(if(show) Icons.Default.VisibilityOff else Icons.Default.Visibility,null)}})
        Spacer(Modifier.height(12.dp))
        Text("MODEL ID",color=Cyan)
        OutlinedTextField(value=model,onValueChange={model=it},modifier=Modifier.fillMaxWidth(),singleLine=true)
        Spacer(Modifier.height(8.dp))
        Text("Base URL: ${selected.base}",fontSize=11.sp,color=Color.LightGray)
        Spacer(Modifier.height(16.dp))
        Button(onClick={
            KeyStore.save(context,selected.name,key.trim()); KeyStore.saveSelection(context,selected.name,model.trim())
            onSelected(selected.name,model.trim(),key.trim(),selected.base); status="API Key saved securely on this device."
        },modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Cyan,contentColor=Deep)) { Text("SAVE API KEY") }
        OutlinedButton(onClick={
            scope.launch {
                busy=true; status="Testing connection..."
                try { AIManager.ask(selected,model,key,"Reply with exactly: ROSE AI connected.",emptyList()); status="Connection successful ✓" }
                catch(e:Exception){status="Connection failed: ${e.message}"}
                busy=false
            }
        },enabled=!busy,modifier=Modifier.fillMaxWidth()) { Text(if(busy)"TESTING..." else "TEST CONNECTION") }
        Text(status,color=if(status.contains("successful")) Cyan else Color.White,fontSize=12.sp)
        Spacer(Modifier.height(20.dp))
        Text("Keep your API key private. Never commit keys to GitHub. For a public release, use a protected backend proxy.",color=Color.LightGray,fontSize=11.sp)
    }
}
