package com.rose.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.launch

private val Deep = Color(0xFF06143B)
private val Panel = Color(0xFF102B68)
private val Cyan = Color(0xFF36E8FF)
private val Pink = Color(0xFFFF73D2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RoseTheme { RoseApp() } }
    }
}

@Composable
fun RoseTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Cyan, secondary = Pink, background = Deep, surface = Panel,
        onPrimary = Deep, onBackground = Color.White, onSurface = Color.White
    ), content = content)
}

@Composable
fun RoseApp() {
    val context = LocalContext.current
    val saved = remember { KeyStore.selection(context) }
    var page by remember { mutableStateOf("home") }
    var provider by remember { mutableStateOf(saved.first) }
    var model by remember { mutableStateOf(saved.second) }
    var apiKey by remember { mutableStateOf(KeyStore.read(context, saved.first)) }
    var baseUrl by remember { mutableStateOf(AIManager.providers.first { it.name == saved.first }.base) }
    Surface(Modifier.fillMaxSize(), color = Deep) {
        when (page) {
            "settings" -> ApiSettingsScreen(
                onBack = { page = "home" },
                onSelected = { p, m, k, b -> provider=p; model=m; apiKey=k; baseUrl=b }
            )
            "chat" -> ChatScreen(provider, model, apiKey, baseUrl, onBack={page="home"})
            else -> HomeScreen(
                provider = provider,
                onChat = { page="chat" },
                onSettings = { page="settings" },
                onNavigate = { if (it=="Chat") page="chat" else if(it=="Settings") page="settings" }
            )
        }
    }
}

@Composable
fun HomeScreen(provider:String, onChat:()->Unit, onSettings:()->Unit, onNavigate:(String)->Unit) {
    val pulse = rememberInfiniteTransition(label="pulse")
    val scale by pulse.animateFloat(1f, 1.045f, infiniteRepeatable(tween(1100), RepeatMode.Reverse), label="scale")
    Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF02091E), Color(0xFF092F75), Color(0xFF160B42))))) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal=18.dp)) {
            Row(Modifier.fillMaxWidth().padding(top=12.dp), verticalAlignment=Alignment.CenterVertically) {
                Surface(shape=CircleShape,color=Panel,modifier=Modifier.size(44.dp).clickable { onSettings() }) {
                    Box(contentAlignment=Alignment.Center){ Icon(Icons.Default.Menu,null,tint=Cyan) }
                }
                Spacer(Modifier.width(12.dp))
                Text("ROSE",fontSize=25.sp,fontWeight=FontWeight.Black,letterSpacing=3.sp)
                Spacer(Modifier.weight(1f))
                NeonChip("⚡ 21 Energy")
                IconButton(onClick=onSettings){Icon(Icons.Default.Settings,null,tint=Cyan)}
            }
            Spacer(Modifier.height(20.dp))
            Text("Good afternoon,",fontSize=18.sp,fontWeight=FontWeight.SemiBold,color=Color.White.copy(.85f))
            Text("friend",fontSize=36.sp,fontWeight=FontWeight.Black)
            Text("Rose is here for you ✨",color=Cyan,fontSize=13.sp)
            Box(Modifier.weight(1f).fillMaxWidth(),contentAlignment=Alignment.Center) {
                Box(Modifier.size(290.dp).background(Brush.radialGradient(listOf(Cyan.copy(.20f),Color.Transparent)),CircleShape))
                Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.scale(scale)) {
                    // Stylized character placeholder: custom vector-like avatar, replace with licensed artwork.
                    Box(Modifier.size(174.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFFFFD9C8),Color(0xFFE9A6B2)))).border(3.dp,Cyan,CircleShape),contentAlignment=Alignment.Center) {
                        Text("🌸",fontSize=84.sp)
                    }
                    Spacer(Modifier.height(10.dp))
                    Text("ROSE",fontSize=26.sp,fontWeight=FontWeight.Black,letterSpacing=5.sp,color=Color.White)
                    Text("YOUR AI COMPANION",fontSize=10.sp,letterSpacing=3.sp,color=Cyan)
                }
                Column(Modifier.align(Alignment.CenterStart)) { NeonChip("✦ AI ONLINE") }
            }
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                HomeAction("♫","Music",Modifier.weight(1f)){}
                HomeAction("▣","Study",Modifier.weight(1f)){}
                HomeAction("✎","Journal",Modifier.weight(1f)){}
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                InfoTile("☀","Weather","Set your city",Modifier.weight(1f))
                InfoTile("▣","Today",java.time.LocalDate.now().toString(),Modifier.weight(1f))
                InfoTile("♥","Mood","Stay happy",Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
            Surface(Modifier.fillMaxWidth().clickable { onChat() },shape=RoundedCornerShape(22.dp),color=Color.White.copy(.09f),border=BorderStroke(1.dp,Cyan.copy(.45f))) {
                Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically) {
                    Icon(Icons.Default.ChatBubbleOutline,null,tint=Cyan)
                    Spacer(Modifier.width(12.dp)); Text("Rose se kuch bhi poochho...",Modifier.weight(1f),color=Color.White.copy(.75f))
                    Icon(Icons.Default.Send,null,tint=Cyan)
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth().padding(bottom=12.dp),horizontalArrangement=Arrangement.SpaceAround) {
                BottomItem("Home",Icons.Default.Home,true){ }
                BottomItem("Scan",Icons.Default.QrCodeScanner,false){ }
                BottomItem("Voice",Icons.Default.Mic,false){ onChat() }
                BottomItem("Yaadein",Icons.Default.FavoriteBorder,false){ }
                BottomItem("Chat",Icons.Default.Chat,false){ onChat() }
            }
        }
    }
}

@Composable fun NeonChip(text:String) {
    Surface(shape=RoundedCornerShape(30.dp),color=Color(0xFF164A9C),border=BorderStroke(1.dp,Cyan.copy(.5f))) {
        Text(text,Modifier.padding(horizontal=12.dp,vertical=8.dp),fontSize=11.sp,fontWeight=FontWeight.Bold,color=Color.White)
    }
}
@Composable fun HomeAction(icon:String,label:String,modifier:Modifier=Modifier,onClick:()->Unit) {
    Surface(modifier.height(48.dp).clickable(onClick=onClick),shape=RoundedCornerShape(16.dp),color=Color(0xFF12418D),border=BorderStroke(1.dp,Cyan.copy(.35f))) {
        Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.Center) { Text(icon,color=Cyan); Spacer(Modifier.width(6.dp));Text(label,fontWeight=FontWeight.Bold,fontSize=12.sp) }
    }
}
@Composable fun InfoTile(icon:String,title:String,value:String,modifier:Modifier=Modifier) {
    Surface(modifier.height(94.dp),shape=RoundedCornerShape(17.dp),color=Color.White.copy(.08f),border=BorderStroke(1.dp,Cyan.copy(.22f))) {
        Column(Modifier.padding(10.dp),verticalArrangement=Arrangement.spacedBy(3.dp)) {
            Text(icon,color=Cyan); Text(title,fontSize=11.sp,color=Color.White.copy(.7f)); Text(value,fontSize=12.sp,fontWeight=FontWeight.Bold,maxLines=2)
        }
    }
}
@Composable fun BottomItem(label:String,icon:androidx.compose.ui.graphics.vector.ImageVector,selected:Boolean,onClick:()->Unit) {
    Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.clickable(onClick=onClick)) {
        Icon(icon,null,tint=if(selected) Cyan else Color.White.copy(.65f))
        Text(label,fontSize=9.sp,color=if(selected) Cyan else Color.White.copy(.65f))
    }
}
