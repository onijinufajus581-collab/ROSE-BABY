package com.rose.ai

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import kotlinx.coroutines.launch

data class RoseMessage(val fromUser:Boolean,val text:String)

@Composable
fun ChatScreen(providerName:String,model:String,apiKey:String,baseUrl:String,onBack:()->Unit) {
    val context= LocalContext.current
    val selection=remember { KeyStore.selection(context) }
    val provider=AIManager.providers.firstOrNull{it.name==providerName} ?: AIManager.providers.first{it.name==selection.first}
    val chosenModel=model.ifBlank { selection.second }
    val chosenKey=apiKey.ifBlank { KeyStore.read(context,provider.name) }
    val field= remember { mutableStateOf("") }
    val messages= remember { mutableStateListOf<RoseMessage>() }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val scope= rememberCoroutineScope()
    Column(Modifier.fillMaxSize().background(Deep).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically) {
            IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null,tint=Cyan)}
            Column { Text("Chat with Rose",fontSize=20.sp,fontWeight=FontWeight.Bold);Text("${provider.name} • $chosenModel",fontSize=10.sp,color=Cyan) }
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal=12.dp),reverseLayout=false,contentPadding=PaddingValues(vertical=8.dp)) {
            itemsIndexed(messages) { _,m ->
                Row(Modifier.fillMaxWidth(),horizontalArrangement=if(m.fromUser) Arrangement.End else Arrangement.Start) {
                    Surface(Modifier.padding(vertical=5.dp).widthIn(max=310.dp),shape=RoundedCornerShape(18.dp),color=if(m.fromUser) Color(0xFF1264C8) else Panel,border=BorderStroke(1.dp,Cyan.copy(.25f))) {
                        Text(m.text,Modifier.padding(13.dp),color=Color.White,fontSize=14.sp)
                    }
                }
            }
            if(busy) item { CircularProgressIndicator(color=Cyan,modifier=Modifier.size(24.dp).padding(4.dp)) }
        }
        if(error.isNotBlank()) Text(error,Modifier.padding(horizontal=14.dp),color=Pink,fontSize=11.sp)
        Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically) {
            OutlinedTextField(value=field.value,onValueChange={field.value=it},modifier=Modifier.weight(1f),placeholder={Text("Message Rose...")},maxLines=4,shape=RoundedCornerShape(24.dp))
            IconButton(enabled=!busy,onClick={
                val prompt=field.value.trim()
                if(prompt.isNotEmpty()) {
                    field.value=""; messages.add(RoseMessage(true,prompt)); error=""
                    scope.launch {
                        busy=true
                        try {
                            val history=messages.dropLast(1).map{it.fromUser to it.text}
                            val answer=AIManager.ask(provider,chosenModel,chosenKey,prompt,history)
                            messages.add(RoseMessage(false,answer))
                        } catch(e:Exception) { error=e.message ?: "Unknown error" }
                        busy=false
                    }
                }
            }) { Icon(Icons.Default.Send,null,tint=Cyan) }
        }
    }
}
