package com.rose.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class Provider(val name:String,val base:String,val defaultModel:String,val gemini:Boolean=false)
object AIManager {
    val providers = listOf(
        Provider("Groq","https://api.groq.com/openai/v1","llama-3.3-70b-versatile"),
        Provider("OpenRouter","https://openrouter.ai/api/v1","openai/gpt-4o-mini"),
        Provider("Mistral","https://api.mistral.ai/v1","mistral-small-latest"),
        Provider("Google Gemini","https://generativelanguage.googleapis.com/v1beta","gemini-2.0-flash",true)
    )
    private val client = OkHttpClient.Builder().callTimeout(60,TimeUnit.SECONDS).build()
    suspend fun ask(provider:Provider, model:String, key:String, prompt:String, history:List<Pair<Boolean,String>>):String = withContext(Dispatchers.IO) {
        require(key.isNotBlank()) { "Settings-এ API Key যোগ করুন।" }
        val body:JSONObject
        val url:String
        val builder=Request.Builder()
        if(provider.gemini) {
            url="${provider.base}/models/$model:generateContent?key=$key"
            val parts=org.json.JSONArray().put(JSONObject().put("text",prompt))
            body=JSONObject().put("contents",org.json.JSONArray().put(JSONObject().put("parts",parts)))
            builder.url(url).post(body.toString().toRequestBody("application/json".toMediaType()))
        } else {
            url="${provider.base}/chat/completions"
            val msgs=org.json.JSONArray().put(JSONObject().put("role","system").put("content","You are Rose, a warm and helpful female AI companion. Reply in the user's language."))
            history.forEach { (user,text)-> msgs.put(JSONObject().put("role",if(user)"user" else "assistant").put("content",text)) }
            msgs.put(JSONObject().put("role","user").put("content",prompt))
            body=JSONObject().put("model",model).put("messages",msgs)
            builder.url(url).header("Authorization","Bearer $key").post(body.toString().toRequestBody("application/json".toMediaType()))
            if(provider.name=="OpenRouter") builder.header("HTTP-Referer","https://github.com/").header("X-Title","ROSE AI")
        }
        val response=client.newCall(builder.header("Content-Type","application/json").build()).execute()
        val raw=response.body?.string().orEmpty()
        if(!response.isSuccessful) throw IllegalStateException("HTTP ${response.code}: $raw")
        val json=JSONObject(raw)
        if(provider.gemini) json.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        else json.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
    }
}
