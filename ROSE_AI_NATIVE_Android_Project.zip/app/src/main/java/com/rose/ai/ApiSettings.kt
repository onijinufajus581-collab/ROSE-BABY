package com.rose.ai

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

object KeyStore {
    private fun prefs(context:Context) = EncryptedSharedPreferences.create(
        context,"rose_secure_settings",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
    fun save(context:Context,provider:String,key:String) { prefs(context).edit().putString("key_$provider",key).apply() }
    fun read(context:Context,provider:String):String = prefs(context).getString("key_$provider","").orEmpty()
    fun saveSelection(context:Context,name:String,model:String) { prefs(context).edit().putString("provider",name).putString("model",model).apply() }
    fun selection(context:Context):Pair<String,String> {
        val p=prefs(context); val name=p.getString("provider","Groq") ?: "Groq"
        val model=p.getString("model",AIManager.providers.first{it.name==name}.defaultModel) ?: AIManager.providers.first{it.name==name}.defaultModel
        return name to model
    }
}
